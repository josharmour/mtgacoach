using System;
using System.Runtime.InteropServices;

namespace Epic.OnlineServices.Sessions;

[StructLayout(LayoutKind.Sequential, Pack = 8)]
internal struct SessionModificationAddAttributeOptions_ : IDisposable
{
	private int m_ApiVersion;

	private IntPtr m_SessionAttribute;

	private SessionAttributeAdvertisementType m_AdvertisementType;

	public int ApiVersion
	{
		get
		{
			return m_ApiVersion;
		}
		set
		{
			m_ApiVersion = value;
		}
	}

	public AttributeData_ SessionAttribute
	{
		get
		{
			return Helper.GetAllocation<AttributeData_>(m_SessionAttribute);
		}
		set
		{
			Helper.RegisterAllocation(ref m_SessionAttribute, value);
		}
	}

	public SessionAttributeAdvertisementType AdvertisementType
	{
		get
		{
			return m_AdvertisementType;
		}
		set
		{
			m_AdvertisementType = value;
		}
	}

	public void Dispose()
	{
		Helper.ReleaseAllocation(ref m_SessionAttribute);
	}
}
