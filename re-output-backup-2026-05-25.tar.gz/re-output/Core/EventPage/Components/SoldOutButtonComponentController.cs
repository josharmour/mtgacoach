using System;
using Wizards.Arena.Enums.Event;
using Wizards.MDN;
using Wizards.Mtga.FrontDoorModels;
using Wotc.Mtga.Events;

namespace EventPage.Components;

public class SoldOutButtonComponentController : IComponentController
{
	private EventButtonComponent _component;

	public SoldOutButtonComponentController(EventButtonComponent component, Action onClick)
	{
		_component = component;
		EventButtonComponent component2 = _component;
		component2.OnClick = (Action)Delegate.Remove(component2.OnClick, onClick);
		EventButtonComponent component3 = _component;
		component3.OnClick = (Action)Delegate.Combine(component3.OnClick, onClick);
	}

	public void OnEventPageOpen(EventContext eventContext)
	{
	}

	public void OnEventPageStateChanged(IPlayerEvent playerEvent, EventPageStates state)
	{
		if (state != EventPageStates.DisplayEvent)
		{
			_component.gameObject.SetActive(value: false);
		}
		else
		{
			Update(playerEvent);
		}
	}

	public void Update(IPlayerEvent playerEvent)
	{
		PlayerEventModule playerEventModule = playerEvent.CourseData?.CurrentModule ?? PlayerEventModule.Join;
		bool flag = playerEvent.EventUXInfo.Joinability == JoinType.Closed;
		flag = flag && (playerEventModule == PlayerEventModule.Join || playerEventModule == PlayerEventModule.Pay || playerEventModule == PlayerEventModule.PayEntry);
		_component.gameObject.SetActive(flag);
		if (flag)
		{
			_component.SetLocText("Events/Button_SoldOut");
		}
	}
}
